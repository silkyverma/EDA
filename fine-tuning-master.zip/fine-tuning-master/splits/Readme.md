Splits for the different datasets
