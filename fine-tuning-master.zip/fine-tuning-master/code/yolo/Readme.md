Files for using the YOLO model
